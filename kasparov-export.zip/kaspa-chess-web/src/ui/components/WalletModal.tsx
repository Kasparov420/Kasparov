import React, { useState } from 'react'

export default function WalletModal({ open, onClose, onConnectKasware, onConnectKastle, wallets }: any) {
  const [connecting, setConnecting] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleConnect = async (type: 'kasware' | 'kastle') => {
    setConnecting(type)
    setError(null)
    try {
      const session = type === 'kasware'
        ? await onConnectKasware()
        : await onConnectKastle()

      if (!session?.address) {
        throw new Error('Wallet did not return an address')
      }

      onClose()
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Connection failed')
    } finally {
      setConnecting(null)
    }
  }

  if (!open) return null
  return (
    <div className="modalBackdrop" onClick={onClose}>
      <div className="walletModal" onClick={(e) => e.stopPropagation()}>
        <button className="closeBtn" onClick={onClose} aria-label="Close">✕</button>
        <div className="modalHeader">
          <h2>Connect Wallet</h2>
        </div>
        
        <div className="modalContent">
          <div className="walletOptions">
            <button 
              className="walletOption kasware" 
              onClick={() => handleConnect('kasware')}
              disabled={!wallets?.kasware || connecting !== null}
            >
              <div className="walletLogoWrap">
                <img className="walletLogo" src="/wallets/kasware.svg" alt="Kasware" />
              </div>
              <div className="walletInfo">
                <div className="walletName">Kasware</div>
                <div className="walletStatus">
                  {!wallets?.kasware ? 'Not Installed' : 'Click to connect'}
                </div>
              </div>
              {connecting === 'kasware' && <div className="spinner"></div>}
            </button>

            <button 
              className="walletOption kastle" 
              onClick={() => handleConnect('kastle')}
              disabled={!wallets?.kastle || connecting !== null}
            >
              <div className="walletLogoWrap">
                <img className="walletLogo" src="/wallets/kastle.svg" alt="Kastle" />
              </div>
              <div className="walletInfo">
                <div className="walletName">Kastle</div>
                <div className="walletStatus">
                  {!wallets?.kastle ? 'Not Installed' : 'Click to connect'}
                </div>
              </div>
              {connecting === 'kastle' && <div className="spinner"></div>}
            </button>
          </div>

          {error && <div className="errorBox">{error}</div>}

        </div>
      </div>
    </div>
  )
}
