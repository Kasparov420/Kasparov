import React, { useEffect, useRef, useState } from 'react'
import BoardStage from './components/BoardStage'
import TopBar from './components/TopBar'
import RightPanel from './components/RightPanel'
import WalletModal from './components/WalletModal'
import { detectWallets, connectKasware, connectKastle, type WalletSession } from '../wallet/wallet'
import DonateKasparov from './components/DonateKasparov'
import { themeFromSeed, randomTheme, type Theme } from '../theme'

type Game = {
  id: string
  createdAt: number
  white: { address: string }
  black?: { address: string }
  fen: string
  turn: 'w' | 'b'
  status: 'waiting' | 'active' | 'ended'
  themeSeed: string
  lastMoveUci?: string
  moveCount: number
}

export default function App() {
  const [session, setSession] = useState<WalletSession | null>(null)
  const [wallets, setWallets] = useState(() => detectWallets())
  const [game, setGame] = useState<Game | null>(null)
  const [showWalletModal, setShowWalletModal] = useState(false)
  const [theme, setTheme] = useState<Theme>(() => randomTheme())
  const [screen, setScreen] = useState<'lobby' | 'playing'>('lobby')
  const wsRef = useRef<WebSocket | null>(null)

  useEffect(() => {
    const t = setInterval(() => setWallets(detectWallets()), 1000)
    return () => clearInterval(t)
  }, [])

  // Random theme while waiting, freeze when active
  useEffect(() => {
    if (!game) return
    if (game.status === 'waiting') {
      const t = setInterval(() => setTheme(randomTheme()), 800)
      return () => clearInterval(t)
    }
    if (game.status === 'active') {
      setTheme(themeFromSeed(game.themeSeed))
    }
  }, [game?.status, game?.themeSeed])

  // WebSocket sync
  useEffect(() => {
    if (!game?.id) return
    const proto = location.protocol === 'https:' ? 'wss' : 'ws'
    const ws = new WebSocket(\`\${proto}://\${location.host}/ws?game=\${encodeURIComponent(game.id)}\`)
    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data)
        if (msg.type === 'game' && msg.game) {
          setGame(msg.game)
          if (msg.game.status === 'active' && screen !== 'playing') {
            setScreen('playing')
          }
        }
      } catch {
        // ignore
      }
    }
    wsRef.current?.close()
    wsRef.current = ws
    return () => ws.close()
  }, [game?.id, screen])

  async function onConnectKasware() {
    const s = await connectKasware('kaspa_mainnet')
    setSession(s)
    return s
  }

  async function onConnectKastle() {
    const s = await connectKastle('kaspa_mainnet')
    setSession(s)
    return s
  }

  function onDisconnect() {
    setSession(null)
  }

  async function onCreate() {
    if (!session) {
      setShowWalletModal(true)
      return
    }
    try {
      const res = await fetch('/api/games', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ address: session.address })
      })
      if (!res.ok) throw new Error(await res.text())
      const data = await res.json()
      setGame(data.game)
      setScreen('lobby')
    } catch (e) {
      alert('Error creating game: ' + (e instanceof Error ? e.message : String(e)))
    }
  }

  async function onJoin(gameId: string) {
    if (!session) {
      setShowWalletModal(true)
      return
    }
    try {
      const res = await fetch(\`/api/games/\${gameId}/join\`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ address: session.address })
      })
      if (!res.ok) throw new Error(await res.text())
      const data = await res.json()
      setGame(data.game)
      setScreen('playing')
    } catch (e) {
      alert('Error joining game: ' + (e instanceof Error ? e.message : String(e)))
    }
  }

  async function onMove(from: string, to: string) {
    if (!game || !session) return false
    const uci = from + to
    try {
      const res = await fetch(\`/api/games/\${game.id}/move\`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ address: session.address, uci })
      })
      if (!res.ok) {
        const err = await res.json()
        throw new Error(err.error || 'move failed')
      }
      const data = await res.json()
      setGame(data.game)
      return true
    } catch (e) {
      alert('Move failed: ' + (e instanceof Error ? e.message : String(e)))
      return false
    }
  }

  const myColor = game
    ? session?.address === game.white.address
      ? 'white'
      : session?.address === game.black?.address
        ? 'black'
        : null
    : null

  const myTurn = game
    ? game.status === 'active' &&
      ((game.turn === 'w' && myColor === 'white') ||
       (game.turn === 'b' && myColor === 'black'))
    : false

  const orientation = myColor === 'black' ? 'black' : 'white'

  return (
    <div className="app">
      <TopBar session={session} onConnect={() => setShowWalletModal(true)} onDisconnect={onDisconnect} />
      <main className="mainLayout">
        <div className="leftCol">
          {game ? (
            <div style={{
              ['--sqLight' as any]: theme.light,
              ['--sqDark' as any]: theme.dark,
              ['--accent' as any]: theme.accent,
            } as React.CSSProperties}>
              <BoardStage
                fen={game.fen}
                onMove={myTurn ? onMove : undefined}
                orientation={orientation}
              />
            </div>
          ) : (
            <div style={{ padding: 40, textAlign: 'center', color: '#ccc' }}>
              Select or create a game
            </div>
          )}
        </div>
        <div className="rightCol">
          <RightPanel
            game={game}
            myColor={myColor}
            myTurn={myTurn}
            session={session}
            onCreate={onCreate}
            onJoin={onJoin}
            onOpenWalletModal={() => setShowWalletModal(true)}
            screen={screen}
          />
        </div>
      </main>
      <WalletModal
        open={showWalletModal}
        onClose={() => setShowWalletModal(false)}
        onConnectKasware={onConnectKasware}
        onConnectKastle={onConnectKastle}
        wallets={wallets}
      />
      <DonateKasparov />
    </div>
  )
}
